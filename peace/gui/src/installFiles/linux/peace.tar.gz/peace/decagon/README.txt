Distributed Environment for Comparative Analysis of Genomic-Assemblers 
Compare about 10 things:

 1. Peak memory
 2. Runtime
 3. A-score
 4. N50
 5. Singletons
 6. Contig Sizes
 7. Jaccard index?
 8. Rand Index?
 9. Parallelism and Scalability
10. FRC
