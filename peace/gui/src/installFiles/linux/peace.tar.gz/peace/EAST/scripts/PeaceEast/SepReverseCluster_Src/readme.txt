SepReverseCluster.cpp:
Separate all the clusters and make all the reads into the forward direction.

Input: estfile, mstfile
Output: 
1) a series of files with the name "estfile.i", here "i" is the index of the cluster.
2) series of files with the name "estfile.i.aceinfo".

